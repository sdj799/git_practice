package chap03;

public class Radio extends Product {

	public Radio() {
		super(500, "radio");
	}
}
