package chap03;

public class Tv extends Product {

	public Tv() {
		super(600, "tv");
	}
}
