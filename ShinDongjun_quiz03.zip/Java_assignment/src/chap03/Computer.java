package chap03;

public class Computer extends Product {

	public Computer() {
		super(1000, "com");
	}
}
