package chap03;

public class Product {

	public int price;
	public String name;
	
	public Product(int price, String name) {
		this.price = price;
		this.name = name;
	}
}
