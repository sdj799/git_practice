package chap2.quiz01;

public class Student extends Person {

	String studentId;
	
	@Override
	String info(String name, int age) {
		return super.info(name, age);
	}

	
}
