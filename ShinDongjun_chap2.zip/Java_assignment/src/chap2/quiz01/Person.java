package chap2.quiz01;

public class Person {

	String name;
	int age;
	
	String info(String name, int age) {
		
		return "이름: "+ name + ", 나이: "+age;
	}
}
