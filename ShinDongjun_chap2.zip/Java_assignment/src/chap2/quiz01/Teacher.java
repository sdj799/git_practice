package chap2.quiz01;

public class Teacher extends Person {

	String subject;

	@Override
	String info(String name, int age) {
		return super.info(name, age);
	}
	
	
}
