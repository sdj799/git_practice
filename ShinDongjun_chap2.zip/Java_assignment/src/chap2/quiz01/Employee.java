package chap2.quiz01;

public class Employee extends Person {

	String departments;

	@Override
	String info(String name, int age) {
		return super.info(name, age);
	}
	
	
}
